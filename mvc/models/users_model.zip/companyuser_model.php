<?php

class Companyuser_model extends CI_Model {

    /**
    * Validate the login's data with the database
    * @param string $user_name
    * @param string $password
    * @return void
    */
	function validate($user_name, $password)
	{
		$this->db->where('user_name', $user_name);
		$this->db->where('password', $password);
		$query = $this->db->get('users');
		
		if($query->num_rows == 1)
		{
			return true;
		}		
	}

	
	
	function select_by_username($user_name, $password)
	{
		$this->db->select('*');
		$this->db->from('users');		
		$this->db->where('user_name', $user_name);
		$this->db->where('password', $password);		
		$query = $this->db->get();
		return $query->result_array(); 		
	}
	
	
	function select_authinteciate_user($userid,$user_name)
	{
		$this->db->select('*');
		$this->db->from('users');		
		$this->db->where('user_name', $user_name);
		$this->db->where('id', $userid);
		$this->db->join('users_groups','users_groups.user_id = users.id');	
		//$this->db->join('groups','groups.id =users_groups.group_id');		
		$query = $this->db->get();
		return $query->result_array(); 		
	}
	
	function select_by_apptheme($userid)
	{
		$this->db->select('*');
		$this->db->from('themes_users');		
		$this->db->where('userid', $userid);
		$this->db->order_by('id', 'DESC');
		$this->db->limit('1');			
		$query = $this->db->get();
		return $query->result_array(); 		
	}
	
	function select_by_appthemeefault()
	{
		$this->db->select('*');
		$this->db->from('theme_default');
		$this->db->order_by('theme_created', 'DESC');
		$this->db->limit('1');		
		$query = $this->db->get();
		return $query->result_array(); 		
	}
	
	
	function get_userdetails_by_id($id)
	{
		$this->db->select('*');
		$this->db->from('users');
		$this->db->where('users.id', $id);
		$this->db->join('users_groups','users_groups.user_id = users.id');	
		$this->db->join('groups','groups.id =users_groups.group_id');
		$this->db->join('hostingplan_tbl','hostingplan_tbl.id =users.hosting_planid');			
		$query = $this->db->get();
		return $query->result_array(); 		
	}
	
	
	function get_employeeuser_id($id)
	{
		$this->db->select('*');
		$this->db->from('users');
		$this->db->where('users.id', $id);
		$this->db->where('users.usertype_group','7');		
		$this->db->join('users_groups','users_groups.user_id = users.id');	
		$this->db->join('groups','groups.id =users_groups.group_id');
		
		$query = $this->db->get();
		return $query->result_array(); 		
	}
	
	
	
	function get_userdetailsid($userid)
	{
		$this->db->select('*');
		$this->db->from('users');
		$this->db->where('users.id', $userid);			
		$query = $this->db->get();
		return $query->result_array(); 		
	}
	
	  /**
    * Update courses
    * @param array $data - associative array with data to store
    * @return boolean
    */
    function update_pwduser($id, $data)
    {
		$this->db->where('id', $id);
		$this->db->where('users.usertype_group','7');
		$this->db->update('users', $data);
		$report = array();
		$report['error'] = $this->db->_error_number();
		$report['message'] = $this->db->_error_message();
		if($report !== 0){
			return true;
		}else{
			return false;
		}
	}
	
	 function update_pwduseradminnew($id, $data)
    {
		$this->db->where('id', $id);
		$this->db->update('users', $data);
		$report = array();
		$report['error'] = $this->db->_error_number();
		$report['message'] = $this->db->_error_message();
		if($report !== 0){
			return true;
		}else{
			return false;
		}
	}
	
		  /**
    * Update courses
    * @param array $data - associative array with data to store
    * @return boolean
    */
    function update_pwduserprofile($id, $data)
    {
		$this->db->where('id', $id);
		$this->db->update('users', $data);
		$report = array();
		$report['error'] = $this->db->_error_number();
		$report['message'] = $this->db->_error_message();
		if($report !== 0){
			return true;
		}else{
			return false;
		}
	}
	
	
	
	  /**
    * Update courses
    * @param array $data - associative array with data to store
    * @return boolean
    */
    function update_filesizeacct($userid, $data)
    {
		$this->db->where('id', $userid);
		$this->db->update('users', $data);
		$report = array();
		$report['error'] = $this->db->_error_number();
		$report['message'] = $this->db->_error_message();
		if($report !== 0){
			return true;
		}else{
			return false;
		}
	}
	
	
    /**
    * Serialize the session data stored in the database, 
    * store it in a new array and return it to the controller 
    * @return array
    */
	function get_db_session_data()
	{
		$query = $this->db->select('user_data')->get('ci_sessions');
		$user = array(); /* array to store the user data we fetch */
		foreach ($query->result() as $row)
		{
		    $udata = unserialize($row->user_data);
		    /* put data in array using username as key */
		    $user['user_name'] = $udata['user_name']; 
		    $user['is_logged_in'] = $udata['is_logged_in'];
			$user['id']= $udata['id'];
			$user['firstname']= $udata['first_name'];
		}
		return $user;
	}
	
    /**
    * Store the new user's data into the database
    * @return boolean - check the insert
    */	
	function create_member()
	{

		$this->db->where('user_name', $this->input->post('username'));
		$query = $this->db->get('membership');

        if($query->num_rows > 0){
        	echo '<div class="alert alert-error"><a class="close" data-dismiss="alert">×</a><strong>';
			  echo "Username already taken";	
			echo '</strong></div>';
		}else{

			$new_member_insert_data = array(
				'first_name' => $this->input->post('first_name'),
				'last_name' => $this->input->post('last_name'),
				'email_addres' => $this->input->post('email_address'),			
				'user_name' => $this->input->post('username'),
				'pass_word' => md5($this->input->post('password'))						
			);
			$insert = $this->db->insert('membership', $new_member_insert_data);
		    return $insert;
		}
	      
	}//create_member
}

