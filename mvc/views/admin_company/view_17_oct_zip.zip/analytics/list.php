<link rel="stylesheet" href="<?php echo base_url(); ?>assets/js/thumbnail/css/jquery-smartvimeoembed.css" type="text/css" />

<div id="content">
	<div class="container">

      <ul class="breadcrumb">
        <li>
          <a href="<?php echo site_url("admin_company"); ?>">
            <?php echo ucfirst($this->uri->segment(1));?>
          </a> 
          <span class="divider">/</span>
        </li>
        <li class="active">
          <?php echo ucfirst($this->uri->segment(2));?>
        </li>
      </ul>	
      
      <div class="row">
        <div class="span12 columns">
          <div class="well">
           
            <?php
           /*
            $attributes = array('class' => 'form-inline reset-margin', 'id' => 'myform');     
			$options_category = array('name'=>'Sub Category Name'); 
		  
            echo form_open('admin_company/subcategory', $attributes);
     
              echo form_label('Search:', 'search_string');
              echo form_input('search_string', $search_string_selected);

              echo form_label('Order by:', 'order');
              echo form_dropdown('order', $options_category, $order, 'class="span2"');

              $data_submit = array('name' => 'mysubmit', 'class' => 'btn btn-primary', 'value' => 'Go');

              $options_order_type = array('Asc' => 'Asc', 'Desc' => 'Desc');
              echo form_dropdown('order_type', $options_order_type, $order_type_selected, 'class="span1"');

              echo form_submit($data_submit);

            echo form_close();
			*/
            ?>

          </div>
		<?php
		$j=0;
		//echo count($courses);
		//for($j=0;$j<count($courses);($j+4))
		
        {
		?>
         <div class="row">
			<?php
				for($i=0;$i<count($courses);$i++)
				{
			?>
					<div class="col-md-6">
						<div class="widget box">
							<div class="widget-header">
								<h4><i class="icon-reorder"></i><?php echo $courses[$i]['course_name'] ; ?></h4>								
							</div>
							<div class="widget-content">
							<?php
							$videoid = $courses[$i]['course_videoid'];
							$id = $courses[$i]['id'];
							/*$dirc=getVimeoThumb($videoid,100);
							var_dump($dirc);*/
							?>							
							
							<img width="340px"  src="http://placehold.it/640x360" class="video-thumb" data-vimeo-id="<?php echo $videoid; ?>" />
							
							<br><br>
                            <table width="100%" border="0" cellspacing="2" cellpadding="2">
								<tbody>								  
								  <tr>
								<?php		
									echo '<td class="crud-actions">
                  <a href="'.site_url("admin_company").'/courses/update/'.$id.'" class="btn btn-info">view & edit</a> &nbsp;&nbsp;';                
                echo '</tr>';	
				?>
									</tr>
									</td>
								  </tr>
								</tbody>
							</table>
							</div>
						</div>
					</div>
    <?php
			}
		}

	?>   
			</div>
          <?php echo '<div class="pagination">'.$this->pagination->create_links().'</div>'; ?>
		</div>
      </div>
<script type="text/javascript">	  
/*
var getVimeoThumbnail = function(id) {
    $.ajax({
        type:'GET',
        url: 'http://vimeo.com/api/v2/video/' + id + '.json',
        jsonp: 'callback',
        dataType: 'jsonp',
        success: function(data){
            var thumbnail_src = data[0].thumbnail_small;
            $('[data-vimeo-id='+id+']').attr('src', thumbnail_src);
        }
    });
};


var drawVimeoImages = function() {
    var vimeoImgDataAttr = 'data-vimeo-id',
        vimeoThumbnails = $('[' + vimeoImgDataAttr + ']'),
        vimeoThumbnailsLength = vimeoThumbnails.length;
    
    if(vimeoThumbnailsLength) {
        for(var i=0, l = vimeoThumbnailsLength; i < l; i++) {
            var vimeoImg = $(vimeoThumbnails).get(i),
                vimeoImgId = $(vimeoImg).attr(vimeoImgDataAttr);
            
            getVimeoThumbnail(vimeoImgId);
        }
    }
};

drawVimeoImages();

var getVimeoThumbnail = function(id) {
    $.ajax({
        type:'GET',
        url: 'http://vimeo.com/api/v2/video/' + id + '.json',
        jsonp: 'callback',
        dataType: 'jsonp',
        success: function(data){
            var thumbnail_src = data[0].thumbnail_small;
            $('[data-vimeo-id='+id+']').attr('src', thumbnail_src);
        }
    });
};

//getVimeoThumbnail(120767266);
getVimeoThumbnail(27246366);
*/
</script>	



<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/thumbnail/jquery-smartvimeoembed.min.js"></script> 
<script src="<?php echo base_url(); ?>assets/js/thumbnail/local.js"></script>

