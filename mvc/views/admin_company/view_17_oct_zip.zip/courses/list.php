<style>
table.primary th
{
    border-bottom-width: 2px;
	border: 1px solid #ddd;
	padding: 5px;
	vertical-align: bottom;
    border-bottom: 2px solid #ddd;
	text-align: left;
	font-weight: bold;
	display: table-cell;
	border-spacing: 2px;
    border-color: grey;
	background-color: #ffffff;
}

table.primary td
{
	border: 1px solid #ddd;   
    border-top: 1px solid #ddd;
}

table.primary tr:nth-child(odd) {
    background-color: #fafafa;
	
	
}
table.primary tr:nth-child(even) {
    background-color: #ffffff;

}
table.primary tr.deactivate{
    background-color: #ffc;
}

</style>

   <div id="content">
	<div class="container">
				<div class="row">
				<br/>
				<div class="row">
					<div class="col-md-12">
						<div class="widget box">
							<div class="widget-header">
								<h2>Course List</h2>
							</div>
							<div class="widget-content">
						      <?php
           
            $attributes = array('class' => 'form-inline reset-margin', 'id' => 'myform');
           
		  $options_category = array('course_name'=>'Course Name'); 
		  
            echo form_open('admin_company/courses', $attributes);
     
             
			echo '<div class="form-group">';
			echo '<label class="col-md-2   control-label">Search:</label>';
			
			echo '<div class="col-md-3">';			  
			  $data_search = array(
              'name'        => 'search_string',
              'id'          => 'search_string',              
              'class'       => 'form-control',
			  'placeholder' => 'Enter Course name',
				);
			  echo form_input($data_search, $search_string_selected);
			echo '</div>';
			
			echo '<label class="col-md-2   control-label">Order by:</label>';			
            //echo form_input('search_string', $search_string_selected);
			echo '<div class="col-md-2" style="padding-left:0px !important; padding-right:0px !important;">';
            echo form_dropdown('order', $options_category, $order, 'class="form-control"');
			echo '</div>';
			
              $data_submit = array('name' => 'mysubmit', 'class' => 'btn btn-primary', 'value' => 'Go');
			
			echo '<div class="col-md-2" style="padding-left:0px !important; padding-right:0px !important;">';
              $options_order_type = array('Asc' => 'Asc', 'Desc' => 'Desc');
              echo form_dropdown('order_type', $options_order_type, $order_type_selected, 'class="form-control"');
			echo '</div>';
              echo form_submit($data_submit);
			echo '</div>';
			
            echo form_close();
            ?>
								
							</div> <!-- /.widget-content -->
						</div> <!-- /.widget .box -->
					</div> <!-- /.col-md-12 -->
				</div> <!-- /.row -->		
				</div> <!-- /.row -->		
				<!-- /Statboxes -->
				<!--=== Normal ===-->
				<div class="row">
					<div class="col-md-12">												
		<?php	
	//echo ($sessionuserdata[0]['space_filled']);
	if($sessionuserdata[0]['space_filled'] =='N')
	{
?>	  
    <a  href="<?php echo site_url("admin_company").'/'.$this->uri->segment(2); ?>/add" class="btn btn-primary">Add a new</a> <?php
}
?> 

<ul class="page-stats">
						<li>
							<div class="summary">
								<span>Total Disk SPace</span>
								<h3><?php echo $totaldiskspace; ?></h3>
							</div>
							
							<!-- Use instead of sparkline e.g. this:
							<div class="graph circular-chart" data-percent="73">73%</div>
							-->
						</li>
						<li>
							<div class="summary">
								<span>Available Disk SPace</span>
								<h3><?php echo $remainspace; ?></h3>
							</div>
							
						</li>
					</ul>
					<!-- /Page Stats -->
				</div>
				<?php
		      //flash messages
		      if($this->session->flashdata('flash_message')){
		        if($this->session->flashdata('flash_message') == 'Retired')
		        {
		          echo '<div class="alert alert-success">';
		            echo '<a class="close" data-dismiss="alert">�</a>';
		            echo '<strong>Well done!!</strong> Courses Retired with success now its not to assign anyone.';
		          echo '</div>';       
		        }else{
		          echo '<div class="alert alert-error">';
		            echo '<a class="close" data-dismiss="alert">�</a>';
		            echo '<strong>Oh snap!</strong> change a few things up and try submitting again.';
		          echo '</div>';          
		        }
		      }
		    ?>  
						<p>&nbsp;</p>
						<div class="widget box">
							<div class="widget-header">
								<h4><i class="icon-reorder"></i>View All Courses</h4>								
							</div>
							<div class="widget-content">
								<table class="primary">
            <thead>
              <tr>
                <th class="header">No</th>
                <th class="yellow header headerSortDown">Name</th>
				<th class="yellow header headerSortDown">Sub Title</th>
				<th class="yellow header headerSortDown">Validity</th>
				<th class="yellow header headerSortDown">Price</th>
				<th class="yellow header headerSortDown">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php
              foreach($courses as $row)
              {
				if($row['IsActive']== "N")
				{
					$clstr='class="deactivate"';
				}
				else
				{
					$clstr='';
				}
				
				{
	                echo '<tr '.$clstr.'>';
	                echo '<td>'.$row['id'].'</td>';
	                echo '<td>'.$row['course_name'].'</td>';
					echo '<td>'.$row['course_subtitle'].'</td>';
					echo '<td>'.$row['course_validity'].'</td>';				
					echo '<td>'.$row['course_price'].'</td>';					

					if($row['IsActive']== "N")
					{
						echo '<td class="crud-actions">
	                  <a href="'.site_url("admin_company").'/courses/update/'.$row['id'].'" class="btn" onclick="return false;">view & edit</a> &nbsp;&nbsp;';  
						echo '<a href="'.site_url("admin_company").'/courses/activate/'.$row['id'].'" class="btn btn-primary">Active Course</a></td>'; 						
					}
					else
					{
						echo '<td class="crud-actions">
	                  <a href="'.site_url("admin_company").'/courses/update/'.$row['id'].'" class="btn btn-info" >view & edit</a> &nbsp;&nbsp;';  
						echo '<a href="'.site_url("admin_company").'/courses/delete/'.$row['id'].'" class="btn btn-warning">Retire Course</a></td>';  
					} 	               
	                echo '</tr>';
				}
				
              }
              ?>       
            </tbody>
          </table>

    <?php echo '<div class="pagination">'.$this->pagination->create_links().'</div>'; ?>

							</div>
						
						</div>
						
					</div>
				</div>
				<!-- /Normal -->
	</div>
				</div>		