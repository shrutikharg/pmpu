   <div id="content">
	<div class="container">
				<div class="row">
				<br/>
				<div class="row">
					<div class="col-md-12">
						<div class="widget box">
							<div class="widget-header">
								<h2>Course Assignment List</h2>
							</div>
							<div class="widget-content">
						  <?php
           
            $attributes = array('class' => 'form-inline reset-margin', 'id' => 'myform');
           
		  $options_category = array('course_name'=>'Course Name'); 
		  
            echo form_open('admin_company/courses', $attributes);
     
              echo form_label('Search:', 'search_string');
              echo form_input('search_string', $search_string_selected);

              echo form_label('Order by:', 'order');
              echo form_dropdown('order', $options_category, $order, 'class="span2"');

              $data_submit = array('name' => 'mysubmit', 'class' => 'btn btn-primary', 'value' => 'Go');

              $options_order_type = array('Asc' => 'Asc', 'Desc' => 'Desc');
              echo form_dropdown('order_type', $options_order_type, $order_type_selected, 'class="span1"');

              echo form_submit($data_submit);

            echo form_close();
			
            ?>
				
<a onclick="javascript:checkAll('form3', true);" href="javascript:void();">check all</a>
<a onclick="javascript:checkAll('form3', false);" href="javascript:void();">uncheck all</a>

								
							</div> <!-- /.widget-content -->
						</div> <!-- /.widget .box -->
					</div> <!-- /.col-md-12 -->
				</div> <!-- /.row -->		
				</div> <!-- /.row -->		
				<!-- /Statboxes -->
				<!--=== Normal ===-->
			
						<p>&nbsp;</p>
						<div class="widget box">
							<div class="widget-header">
								<h4><i class="icon-reorder"></i>View All Course Assignment</h4>								
							</div>
							<div class="widget-content">
								<form name="form3" action="<?php echo site_url("admin_company").'/'.'coursesassign'; ?>/assignall" method="POST">
	<?php
/*echo '<td class="crud-actions">
                  <a href="'.site_url("admin_company").'/coursesassign/assignall/" class="btn btn-info">Assign All Course</a></td>';  
                echo '</tr>'; */
				
				//echo form_submit($data_submit);
	?>
          <table class="table table-striped table-bordered table-condensed">
            <thead>
              <tr>
                <th class="header"></th>
				<th class="header">No</th>
                <th class="yellow header headerSortDown">Name</th>
				<th class="yellow header headerSortDown">Sub Title</th>
				<th class="yellow header headerSortDown">Validity</th>
				<th class="yellow header headerSortDown">Price</th>
				<th class="yellow header headerSortDown">Action</th>
              </tr>
            </thead>
            <tbody>
              <?php
              foreach($courses as $row)
              {
                echo '<tr>';
				echo '<td><input type="checkbox" name="assign_course[]" value="'.$row['id'].'"></td>';  
                echo '<td>'.$row['id'].'</td>';
                echo '<td>'.$row['course_name'].'</td>';
				echo '<td>'.$row['course_subtitle'].'</td>';
				echo '<td>'.$row['course_validity'].'</td>';				
				echo '<td>'.$row['course_price'].'</td>';
				
                echo '<td class="crud-actions">
                  <a href="'.site_url("admin_company").'/coursesassign/update/'.$row['id'].'" class="btn btn-info">Assign Course</a></td>';  
                echo '</tr>';
              }
              ?>      
            </tbody>
          </table>

          <?php echo '<div class="pagination">'.$this->pagination->create_links().'</div>'; ?>
		  </div>
      </div>
    </div>
	
<script type="text/javascript" language="javascript">// <![CDATA[
function checkAll(formname, checktoggle)
{
  var checkboxes = new Array(); 
  checkboxes = document[formname].getElementsByTagName('input');
 
  for (var i=0; i<checkboxes.length; i++)  {
    if (checkboxes[i].type == 'checkbox')   {
      checkboxes[i].checked = checktoggle;
    }
  }
}
// ]]></script>
</form>
							</div>
						
						</div>
						
					</div>
				</div>
				<!-- /Normal -->
	</div>
				</div>		