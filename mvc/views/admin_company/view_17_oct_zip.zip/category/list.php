   <div id="content">
	<div class="container">
				<div class="row">
				<br/>
				<div class="row">
					<div class="col-md-12">
						<div class="widget box">
							<div class="widget-header">
								<h2>Category List</h2>
							</div>
							<div class="widget-content">
						     <?php
           
            $attributes = array('class' => 'form-horizontal row-border', 'id' => 'myform');
        
			$options_category = array('name'=>'Category Name'); 		  
            echo form_open('admin_company/category', $attributes);
			
			echo '<div class="form-group">';
			echo '<label class="col-md-2   control-label">Search:</label>';
			
			echo '<div class="col-md-3">';			  
			  $data_search = array(
              'name'        => 'search_string',
              'id'          => 'search_string',              
              'class'       => 'form-control',
			  'placeholder' => 'Enter course name',
				);
			  echo form_input($data_search, $search_string_selected);
			echo '</div>';
			
			echo '<label class="col-md-2   control-label">Order by:</label>';			
            //echo form_input('search_string', $search_string_selected);
			echo '<div class="col-md-2" style="padding-left:0px !important; padding-right:0px !important;">';
            echo form_dropdown('order', $options_category, $order, 'class="form-control"');
			echo '</div>';
			
              $data_submit = array('name' => 'mysubmit', 'class' => 'btn btn-primary', 'value' => 'Go');
			
			echo '<div class="col-md-2" style="padding-left:0px !important; padding-right:0px !important;">';
              $options_order_type = array('Asc' => 'Asc', 'Desc' => 'Desc');
              echo form_dropdown('order_type', $options_order_type, $order_type_selected, 'class="form-control"');
			echo '</div>';
              echo form_submit($data_submit);
			echo '</div>';
            echo form_close();
            ?>
								
							</div> <!-- /.widget-content -->
						</div> <!-- /.widget .box -->
					</div> <!-- /.col-md-12 -->
				</div> <!-- /.row -->		
				</div> <!-- /.row -->		
				<!-- /Statboxes -->
				
				
				<!--=== Page Content ===-->
				<!--=== Statboxes ===-->		
				
				<!--=== Normal ===-->
				<div class="row">
					<div class="col-md-12">												
		<?php
		$catlimit=$this->session->userdata('user_catlimit');
		if($catlimit &&  ($catlimit > $count_catlimit))
		{				
		?>
		<a  href="<?php echo site_url("admin_company").'/'.$this->uri->segment(2); ?>/add" class="btn btn-primary">Add a new</a>
        </h2>
		 <?php
		}
		?>
						<p>&nbsp;</p>
						<div class="widget box">
							<div class="widget-header">
								<h4><i class="icon-reorder"></i>View All EMPLOYEES</h4>								
							</div>
							<div class="widget-content">
								<table class="table table-striped table-bordered table-condensed">
            <thead>
              <tr>
                <th class="header">No</th>
                <th class="yellow header headerSortDown">Name</th>
				<th class="yellow header headerSortDown">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php
              foreach($category as $row)
              {
                echo '<tr>';
                echo '<td>'.$row['id'].'</td>';
                echo '<td>'.$row['name'].'</td>';
                echo '<td class="crud-actions">
                  <a href="'.site_url("admin_company").'/category/update/'.$row['id'].'" class="btn btn-info">view & edit</a></td>';  
                echo '</tr>';
              }
              ?>      
            </tbody>
          </table>

    <?php echo '<div class="pagination">'.$this->pagination->create_links().'</div>'; ?>

							</div>
						
						</div>
						
					</div>
				</div>
				<!-- /Normal -->
	</div>
				</div>		